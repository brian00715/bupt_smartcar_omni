#ifndef _buzzer_h
#define _buzzer_h

#include "headfile.h"


void buzzer_init(void);

#endif
