#ifndef SLAVE_COMM_H_
#define SLAVE_COMM_H_


void SlaveComm_Init();
void SlaveComm_UARTCallback();
void SlaveComm_Exe();

#endif